<?php
return array (
    'name' => '苹果CMS内容管理系统',
    'copyright' => 'MacCMS',
    'url' => '//github.com/magicblack',
    'code' => '2023.1000.3050',
    'license' => '开源版',
);
?>