<?php
/*
* 生成v10的校验文件，拷贝到对应版本库的根目录执行
*/
error_reporting(E_ERROR | E_PARSE );
@ini_set('max_execution_time', '0');
@ini_set("memory_limit",'-1');
$files=[];

function mac_write_file($f,$c='')
{
    $dir = dirname($f);
    if(!is_dir($dir)){
        mac_mkdirss($dir);
    }
    return @file_put_contents($f, $c);
}

function mac_convert_encoding($str,$nfate,$ofate){
    if ($ofate=="UTF-8"){ return $str; }
    if ($ofate=="GB2312"){ $ofate="GBK"; }

    if(function_exists("mb_convert_encoding")){
        $str=mb_convert_encoding($str,$nfate,$ofate);
    }
    else{
        $ofate.="//IGNORE";
        $str=iconv($nfate ,$ofate ,$str);
    }
    return $str;
}

 function listDir($dir)
 {
     global $files;
     if(is_dir($dir)) {
         if ($dh = opendir($dir)) {
             while (($file = readdir($dh)) !== false) {
                 $tmp = str_replace('//', '/', mac_convert_encoding($dir . $file, "UTF-8", "GB2312"));
                 if ((is_dir($dir . "/" . $file)) && $file != "." && $file != "..") {
                     if (in_array(mac_convert_encoding($file, "UTF-8", "GB2312"), ['.git', '.idea', '说明文档'])) {
                         continue;
                     }
                     //echo "文件夹：", $tmp ."\n";
                     listDir($dir . "/" . $file . "/");
                 } else {
                     if ($file != "." && $file != ".." && $file!='mac_files.html' && $file!='make_files10.php' && $file!='nginx.htaccess' && $file!='.htaccess' && $file!='.DS_Store'){
                         $files[$tmp] = ['md5' => md5_file($dir . $file)];
                         //echo $tmp."\n";
                     }
                 }
             }
             closedir($dh);
         }
     }
 }


listDir('./');
mac_write_file('./mac_files.html',json_encode($files));
print_r($files);