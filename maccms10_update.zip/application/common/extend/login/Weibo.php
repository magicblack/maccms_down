<?php
namespace app\common\extend\login;

class Weibo {

    public $name = 'Weibo';
    public $ver = '1.0';

    public function login($config=[])
    {

    }

    public function callback()
    {

    }
}
