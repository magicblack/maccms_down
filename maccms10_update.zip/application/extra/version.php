<?php
return array (
    'name' => '苹果CMS内容管理系统',
    'copyright' => 'MacCMS',
    'url' => '//github.com/magicblack',
    'code' => '2022.1000.3022',
    'license' => '开源版',
);
?>