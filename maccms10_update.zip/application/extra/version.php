<?php
return array (
    'name' => '苹果CMS内容管理系统',
    'copyright' => 'MacCMS',
    'url' => '//github.com/magicblack',
    'code' => '2024.1000.4040',
    'license' => '开源版',

);
?>