<?php
require_once  __DIR__ . '/src/Aws/aws.phar';
