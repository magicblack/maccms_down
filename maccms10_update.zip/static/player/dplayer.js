MacPlayer.Html = '<iframe border="0" src="'+maccms.path+'/static/player/dplayer.html?v=20261002" width="100%" height="100%" marginWidth="0" frameSpacing="0" marginHeight="0" frameBorder="0" scrolling="no" allowfullscreen="true" allow="fullscreen" vspale="0" noResize></iframe>';
MacPlayer.Show();
