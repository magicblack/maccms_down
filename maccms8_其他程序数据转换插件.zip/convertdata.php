<?php
	ob_end_clean();
	ob_implicit_flush(true);
	ini_set('max_execution_time', '0');
	include("inc/conn.php");
	
	$action = be("all","action");
	switch($action)
	{
		case "ckdb": ckdb();break;
		case "a": show_header(); stepA(); show_footer();break;
		case "b": show_header(); stepB(); show_footer();break;
		case "c": show_header(); stepC(); show_footer();break;
		case "d": show_header(); stepD(); show_footer();break;
		default : show_header(); main(); show_footer();break;
	}
	dispseObj();
	
	function ckdb()
	{
		$type=be("get","type");
		$path=be("get","path");
		$server=be("get","server");
		$dbname=be("get","db");
		$id=be("get","id");
		$pwd=be("get","pwd");
		$n=be("get","n");
		
		if($type=='access'){
			$conn = new com("ADODB.Connection");
			$connstr = "DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=". realpath($path);
			$connstr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=".realpath($path);
			$conn->Open($connstr);
			unset($conn);
		}
		elseif($type=='mysql'){
			$lnk= @mysql_connect($server,$id,$pwd);
			
			if(!$lnk){
				die('servererror');
			}
			else{
				$rs = @mysql_select_db($dbname,$lnk);
				if(!$rs && $n!=''){
				   die('dberror');
				}
			}
			@mysql_close($lnk);
		}
		elseif($type=='mysqli'){
			$lnk = new mysqli($server, $id, $pwd, $dbname, 3306);
			if(mysqli_connect_errno()) {
				die('servererror');
			}
			@mysqli_close($lnk);
		}
		die("ok");
	}
	
	function show_header()
	{
		echo <<<EOT
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>苹果CMS转换数据向导2018.10.25</title>
<link rel="stylesheet" href="images/install/style.css" type="text/css" media="all" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
	function showmessage(message) {
		document.getElementById('notice').innerHTML += message + '<br />';
	}
</script>
<meta content="Comsenz Inc." name="Copyright" />
<style>
	.header h2{ font-size:26px; width:290px; height:48px; margin-left:20px; padding-top:20px; }
</style>
</head>
<div class="container">
	<div class="header">
		<h2>苹果CMS 转换数据向导</h2>
		<span>8x.UTF8版</span>
EOT;
	}
	
	function show_footer()
	{
	echo <<<EOT
		<div class="footer">&copy;2008 - 2014 <a href="http://www.maccms.com/">苹果CMS</a> Inc.</div>
	</div>
</div>
</body>
</html>
EOT;
	}
	
	function show_step($n,$t,$c)
	{
	$laststep = 4;
	$stepclass = array();
	for($i = 1; $i <= $laststep; $i++) {
		$stepclass[$i] = $i == $n ? 'current' : ($i < $n ? '' : 'unactivated');
	}
	$stepclass[$laststep] .= ' last';
	echo <<<EOT
	<div class="setup step{$n}">
		<h2>$t</h2>
		<p>$c</p>
	</div>
	<div class="stepstat">
		<ul>
			<li class="$stepclass[1]">选择系统</li>
			<li class="$stepclass[2]">数据库配置</li>
			<li class="$stepclass[3]">转换数据</li>
			<li class="$stepclass[4]">完成</li>
		</ul>
		<div class="stepstatbg stepstat1"></div>
	</div>
</div>
<div class="main">
EOT;
	}
	
	function main()
	{
		echo <<<EOT
</div>
<div class="main" style="margin-top:-123px;">
	<div class="licenseblock">
	请您在使用(苹果CMS)前仔细阅读如下条款。包括免除或者限制作者责任的免责条款及对用户的权利限制。您的安装使用行为将视为对本《用户许可协议》的接受，并同意接受本《用户许可协议》各项条款的约束。 <br /><br />
				一、安装和使用： <br />苹果CMS是免费和开源提供给您使用的，您可安装无限制数量副本。 您必须保证在不进行非法活动，不违反国家相关政策法规的前提下使用本软件。 <br /><br />
二：郑重声明： <br />
1、任何个人或组织不得在未经授权的情况下删除、修改、拷贝本软件及其他副本上一切关于版权的信息。 <br />
2、苹果工作室保留此软件的法律追究权利。
<br /><br />
				三、免责声明：  <br />
				本软件并无附带任何形式的明示的或暗示的保证，包括任何关于本软件的适用性, 无侵犯知识产权或适合作某一特定用途的保证。  <br />
				在任何情况下，对于因使用本软件或无法使用本软件而导致的任何损害赔偿，作者均无须承担法律责任。作者不保证本软件所包含的资料,文字、图形、链接或其它事项的准确性或完整性。作者可随时更改本软件，无须另作通知。  <br />
				所有由用户自己制作、下载、使用的第三方信息数据和插件所引起的一切版权问题或纠纷，本软件概不承担任何责任。<br /><br />
	<strong>版权所有 (c) 2008-2014，苹果CMS,
	  保留所有权利</strong>。 
	</div>
	<div class="btnbox marginbot">
		<form method="post" action="convertdata.php?action=a">
		<input type="submit" name="submit" value="我同意" style="padding: 2px">&nbsp;
		<input type="button" name="exit" value="我不同意" style="padding: 2px" onclick="javascript: window.close(); return false;">
		</form>
	</div>
EOT;
	}

function dir_writeable($dir){
	$writeable = 0;
	if(!is_dir($dir)) {
		@mkdir($dir, 0777);
	}
	if(is_dir($dir)) {
		if($fp = @fopen("$dir/test.txt", 'w')) {
			@fclose($fp);
			@unlink("$dir/test.txt");
			$writeable = 1;
		} else {
			$writeable = 0;
		}
	}
	return $writeable;
}

function stepA()
{
	show_step(1,"选择系统","需要转换程序系统");
	
	echo <<<EOT
<div class="main"><form name="form2" id="form2" action="convertdata.php?action=b" method="post">
<div id="form_items_3" ><br />
	<div class="desc"><b>请选择所需转换系统</b></div>
	<table class="tb2">
	<tr><th class="tbopt" align="left"><input type="radio" name="xt" value="maccms" checked/>&nbsp; 苹果CMS 7x php</th></tr>
	<tr><th class="tbopt" align="left"><input type="radio" name="xt"value="ffcms"/>&nbsp; 飞飞CMS 2x php</th></tr>
	<tr><th class="tbopt" align="left"><input type="radio" name="xt" value="maxcms"/>&nbsp; 马克斯CMS 4x </th></tr>
	</table>
	</div>
	<table class="tb2"><tr><th class="tbopt" align="left">&nbsp;</th><td><div class="btnbox marginbot"><input type="button" onclick="history.back();" value="上一步"><input type="submit" id="btnNext" value="下一步" ></td><td></td></tr>
</table>
</form>
</div>
EOT;
}

function stepB()
{
	show_step(2,"数据库配置","配置数据源和转换目的");
	$xt = be("post","xt");
?>
<script language="javascript">
$(function(){
	$("#db_type_1").change(function(){
		var p1=$(this).children('option:selected').val();
		
		if(p1=='access'){
			$("#tr_dby_1").show();
			$("#tr_dby_21").hide();
			$("#tr_dby_22").hide();
			$("#tr_dby_23").hide();
			$("#tr_dby_24").hide();
		}
		else{
			$("#tr_dby_21").show();
			$("#tr_dby_22").show();
			$("#tr_dby_23").show();
			$("#tr_dby_24").show();
			$("#tr_dby_1").hide();
			}
	});
	
	$("#btnNext").click(function(){
		$("#form2").submit();
	});
});

function checkdb(n)
{
	var path=$("#db_path_"+n).val();
	var type=$("#db_type_"+n).children('option:selected').val();
	var server=$("#db_server_"+n).val();
	var dbname=$("#db_name_"+n).val();
	var id=$("#db_user_"+n).val();
	var pwd=$("#db_pass_"+n).val();
	
	if(type=='access'){
		if(path==""){
			alert("数据库信息不能为空");
			return;
		}
		
	}
	else{
		if(server=="" || dbname=="" || id=="" || pwd==""){
			alert("数据库信息不能为空");
			return;
		}
	}
	$("#btnNext").attr("disabled","disabled");
	
    $.ajax({cache: false, dataType: 'html', type: 'GET', url: 'convertdata.php?action=ckdb&n='+n+'&type='+type+'&path='+path+'&server='+server+'&db='+dbname+'&id='+id+'&pwd='+pwd,
    	success: function(obj){
			if(obj=='ok'){
				$("#checkinfo_"+n).html( "<font color=green>&nbsp;&nbsp;连接数据库服务器成功!</font>" );
				$("#btnNext").removeAttr("disabled");
			}
			else if(obj=='dberror'){
				$("#checkinfo_"+n).html ("<font color=red>&nbsp;&nbsp;连接数据库服务器成功，但是找不到该数据库!</font>");
			}
			else {
				$("#checkinfo_"+n).html("<font color=red>&nbsp;&nbsp;连接数据库服务器失败!</font>");
			}
		},
		complete: function (XMLHttpRequest, textStatus) {
			if( XMLHttpRequest.responseText.length >10){
				$("#checkinfo_"+n).html("<font color=red>&nbsp;&nbsp;连接服务器失败!</font>");
			}
		}
	});
	
}
</script>
<div class="main"><form name="form2" id="form2" action="convertdata.php?action=b" method="post" onSubmit="">
<div id="form_items_3" ><br /><div class="desc"><b>数据来源信息</b></div>
	<table class="tb2">
	<tr><th class="tbopt" align="left">&nbsp;数据库类型:</th>
	<td>
	<select name="db_type_1" id="db_type_1" >
	<option value="mysql">mysql连接</option>
	<option value="mysqli">mysql-i连接</option>
	<option value="access">access连接</option>
	</select></td>
	<td>网站使用数据库的类型</td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;表前缀:</th>
	<td><input class="txt" type="text" name="db_tablepre_1" id="db_tablepre_1" value="mac_" /></td>
	<td>数据库表名前缀</td>
	</tr>
	<tr id="tr_dby_1" style="display:none"><th class="tbopt" align="left">&nbsp;数据库路径:</th>
	<td><input class="txt" type="text" name="db_path_1" id="db_path_1" value="datas.mdb" /></td>
	<td></td>
	</tr>
	<tr id="tr_dby_21"><th class="tbopt" align="left">&nbsp;数据库服务器:</th>
	<td><input class="txt" type="text" name="db_server_1" id="db_server_1" value="127.0.0.1" /></td>
	<td>数据库服务器地址, 一般为 localhost</td>
	</tr>
	<tr id="tr_dby_22"><th class="tbopt" align="left">&nbsp;数据库名称:</th>
	<td><input class="txt" type="text" name="db_name_1" id="db_name_1" value="" /></td>
	<td></td>
	</tr>
	<tr id="tr_dby_23"><th class="tbopt" align="left">&nbsp;数据库用户名:</th>
	<td><input class="txt" type="text" name="db_user_1" id="db_user_1" value="" /></td>
	<td></td>
	</tr>
	<tr id="tr_dby_24"><th class="tbopt" align="left">&nbsp;数据库密码:</th>
	<td><input class="txt" type="text" name="db_pass_1" id="db_pass_1" value="" /></td>
	<td></td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;测试连接:</th>
	<td><strong><a onclick="checkdb(1)" style="cursor:pointer;"><font color="red">>>>连接测试</font></a></strong></td>
	<td>请确保连接测试可用</td>
	</tr>
	<tr>
	<th>提醒：</th>
	<td colspan=2>access数据库时请检查php是否支持com组件调用(1)extension=php_com_dotnet.dll;(2)com.allow_dcom = true;</td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;</th>
	<td><span id="checkinfo_1"></span></td>
	<td></td>
	</tr>
	</table>
	
	</div>
	<table class="tb2"><tr><th class="tbopt" align="left">&nbsp;</th><td>
<input type="hidden" name="action" value="c" /><input type="hidden" name="xt" value="<?php echo $xt?>" />
		<div class="btnbox marginbot"><input type="button" onclick="history.back();" value="上一步"><input type="button" id="btnNext" value="下一步" disabled></td><td></td></tr>
</table>
</form>
<iframe src="http://www.maccms.com/tongji.html?8x-php" MARGINWIDTH="0" MARGINHEIGHT="0" HSPACE="0" VSPACE="0" FRAMEBORDER="0" SCROLLING="no" width="0" height="0"></iframe>
<?php
}

function fromDealMax($s)
{
	switch($s)
	{
		case "优酷": $res ="youku";break;
		case "迅播高清": $res ="gvod";break;
		case "土豆": $res="tudou";break;
		case "FLV文件": $res ="flv";break;
		case "ppvod高清": $res ="ppvod";break;
		case "SWF数据": $res ="swf";break;
		case "新浪高清": $res ="sinahd";break;
		case "新浪": $res ="sina";break;
		case "56高清": $res ="56hd";break;
		case "土豆高清": $res ="tudouhd";break;
		case "搜狐": $res ="sohu";break;
		case "六间房": $res ="6rooms";break;
		case "qq播客": $res ="qq";break;
		case "ku6视频": $res ="ku6";break;
		case "激动": $res ="joy";break;
		case "奇艺": $res ="qiyi";break;
		case "闪播Pvod": $res ="pvod";break;
		case "皮皮影音": $res ="pipi";break;
		case "百度影音": $res ="baidu";break;
		default : $res= $s;break;
	}
	return $res;
}
function urlDealMax($s)
{
	$res=array();
	$rc1=false;
	$rc2=false;
	
	$arr1 = explode('$$$',$s);
	for($i=0;$i<count($arr1);$i++){
		if($arr1[$i]!=''){
			$arr2 = explode('$$',$arr1[$i]);
			$from = fromDealMax($arr2[0]);
			if($rc1){ $res['from'].='$$$';  $res['url'].='$$$'; }
			$res['from'].=$from;
			$rc2=false;
			
			$arr3 = explode('#',$arr2[1]);
			for($j=0;$j<count($arr3);$j++){
				if($arr3[$j]!=''){
					$arr4 = explode('$',$arr3[$j]);
					if($rc2){ $res['url'].='#'; }
					$res['url'] .= $arr4[0].'$'.$arr4[1];
					$rc2=true;
				}
			}
			$rc1=true;
			
		}
	}
	unset($arr1,$arr2,$arr3,$arr4);
	return $res;
}


function convert_maxcms()
{
	global $db,$db1,$db_type_1,$db_tablepre_1,$db_type_1;
	
	if($db_type_1=="access"){
		
		echo '<script>showmessage(\'开始导入管理员数据，请稍候......\');</script>';
		$i=1;
		$sql="select * from ".$db_tablepre_1."manager";
		$rs=$db1->Execute($sql);
		while(!$rs->EOF)
		{
			$m_name = iconv('gbk','utf-8',$rs->Fields(1)->Value);
			$r=$db->Add( "{pre}manager", array("m_name","m_password","m_levels","m_status"),array($m_name,$rs->Fields(2)->Value,"b,c,d,e,f,g,h,i,j","1") );
			$rs->MoveNext();
			$i++;
		}
		unset($rs);
		echo '<script>showmessage(\'管理员数据导入完毕......\');</script>';
		ob_flush();flush();
		
		echo '<script>showmessage(\'开始导入友情链接数据，请稍候......\');</script>';
		$i=1;
		$sql="select * from ".$db_tablepre_1."link";
		$rs=$db1->Execute($sql);
		while(!$rs->EOF)
		{
			$l_name = iconv('gbk','utf-8',$rs->Fields(2)->Value);
			$l_type = $rs->Fields(1)->Value == 'font' ? '0' : '1';
			$db->Add( "{pre}link", array("l_name","l_type","l_url","l_sort","l_logo"),array($l_name,$rs->Fields(1)->Value,$rs->Fields(4)->Value,$rs->Fields(6)->Value,$rs->Fields(3)->Value) );
			$rs->MoveNext();
			$i++;
		}
		unset($rs);
		echo '<script>showmessage(\'友情链接数据导入完毕......\');</script>';
		ob_flush();flush();
		
		echo '<script>showmessage(\'开始导入文章分类数据，请稍候......\');</script>';
		$i=1;
		$sql="select * from ".$db_tablepre_1."type where m_type=1";
		$rs=$db1->Execute($sql);
		while(!$rs->EOF)
		{
			$t_name = iconv('gbk','utf-8',$rs->Fields(1)->Value);
			$t_key = iconv('gbk','utf-8',$rs->Fields(8)->Value);
			$t_des = iconv('gbk','utf-8',$rs->Fields(9)->Value);
			
			$l_type = $rs->Fields(1)->Value == 'font' ? '0' : '1';
			$db->Add( "{pre}art_type", array("t_id","t_name","t_enname","t_sort","t_pid","t_key","t_des","t_tpl","t_tpl_list","t_tpl_art","t_hide","t_union"),array($rs->Fields(0)->Value,$t_name,$rs->Fields(2)->Value,$rs->Fields(3)->Value,$rs->Fields(4)->Value,$t_key,$t_des,"art_type.html","art_list.html","art_detail.html","0", "") );
			$rs->MoveNext();
			$i++;
		}
		unset($rs);
		echo '<script>showmessage(\'文章分类数据导入完毕......\');</script>';
		ob_flush();flush();
		
		echo '<script>showmessage(\'开始导入视频分类数据，请稍候......\');</script>';
		$i=1;
		$sql="select * from ".$db_tablepre_1."type where m_type=0";
		$rs=$db1->Execute($sql);
		while(!$rs->EOF)
		{
			$t_name = iconv('gbk','utf-8',$rs->Fields(1)->Value);
			$t_key = iconv('gbk','utf-8',$rs->Fields(8)->Value);
			$t_des = iconv('gbk','utf-8',$rs->Fields(9)->Value);
			
			$l_type = $rs->Fields(1)->Value == 'font' ? '0' : '1';
			$db->Add( "{pre}vod_type", array("t_id","t_name","t_enname","t_sort","t_pid","t_key","t_des","t_tpl","t_tpl_list","t_tpl_vod","t_tpl_play","t_tpl_down","t_hide","t_union"),array($rs->Fields(0)->Value,$t_name,$rs->Fields(2)->Value,$rs->Fields(3)->Value,$rs->Fields(4)->Value,$t_key,$t_des,"vod_type.html","vod_list.html","vod_detail.html","vod_play.html","vod_down.html","0", "") );
			$rs->MoveNext();
			$i++;
		}
		unset($rs);
		echo '<script>showmessage(\'视频分类数据导入完毕......\');</script>';
		ob_flush();flush();
		
		echo '<script>showmessage(\'开始导入评论数据，请稍候......\');</script>';
		$i=1;
		$sql="select * from ".$db_tablepre_1."leaveword";
		$rs=$db1->Execute($sql);
		while(!$rs->EOF)
		{
			$g_name = iconv('gbk','utf-8',$rs->Fields(2)->Value);
			$g_content = iconv('gbk','utf-8',$rs->Fields(5)->Value);
			$g_ip = ip2long($rs->Fields(6)->Value);
			$g_time = strtotime($rs->Fields(7)->Value);
			$db->Add( "{pre}gbook", array("g_vid","g_audit","g_name","g_content","g_ip","g_time"),array(0,1,$g_name,$g_content,$g_ip,$g_time) );
			$rs->MoveNext();
			$i++;
		}
		unset($rs);
		echo '<script>showmessage(\'评论数据导入完毕......\');</script>';
		ob_flush();flush();
		
		echo '<script>showmessage(\'开始导入文章数据，请稍候......\');</script>';
		$i=1;
		$sql="select * from ".$db_tablepre_1."news";
		$rs=$db1->Execute($sql);
		while(!$rs->EOF)
		{
			$a_name = iconv('gbk','utf-8',$rs->Fields(3)->Value);
			$a_letter = strtoupper($rs->Fields(21)->Value);
			$a_from = iconv('gbk','utf-8',$rs->Fields(7)->Value);
			$a_content = str_replace("'","''",iconv('gbk','utf-8',$rs->Fields(10)->Value) );
			$a_author = iconv('gbk','utf-8',$rs->Fields(4)->Value);
			$a_addtime = strtotime($rs->Fields(22)->Value);
			$a_time = strtotime($rs->Fields(23)->Value);
			
			$db->Add ( "{pre}art",Array("a_id","a_name","a_enname","a_letter","a_from","a_type","a_content","a_author","a_color","a_hits","a_dayhits","a_weekhits","a_monthhits","a_addtime","a_time"),Array($rs->Fields(0)->Value,$a_name,$rs->Fields(20)->Value,$a_letter,$a_from,$rs->Fields(1)->Value,$a_content,$a_author,$rs->Fields(5)->Value,$rs->Fields(12)->Value,$rs->Fields(13)->Value,$rs->Fields(14)->Value,$rs->Fields(15)->Value,$a_addtime,$a_time) );
			$rs->MoveNext();
			$i++;
		}
		unset($rs);
		echo '<script>showmessage(\'文章数据导入完毕......\');</script>';
		ob_flush();flush();
		
		
		echo '<script>showmessage(\'开始导入视频数据，请稍候......\');</script>';
		$i=1;
		$sql="select * from ".$db_tablepre_1."data";
		$rs=$db1->Execute($sql);
		while(!$rs->EOF)
		{
			$d_name = iconv('gbk','utf-8',$rs->Fields(1)->Value);
			$d_letter = strtoupper($rs->Fields(20)->Value);
			$d_strring = iconv('gbk','utf-8',$rs->Fields(7)->Value);
			$d_directed = iconv('gbk','utf-8',$rs->Fields(23)->Value);
			$d_area = iconv('gbk','utf-8',$rs->Fields(16)->Value);
			$d_lang = iconv('gbk','utf-8',$rs->Fields(24)->Value);
			$d_content = iconv('gbk','utf-8',$rs->Fields(9)->Value);
			$d_remarks = iconv('gbk','utf-8',$rs->Fields(8)->Value);
			$d_pic = strpos($rs->Fields(4)->Value,"ttp://")>0 ? $rs->Fields(4)->Value : "upload/".$rs->Fields(4)->Value;
			$d_addtime = strtotime($rs->Fields(14)->Value);
			$d_time = strtotime($rs->Fields(29)->Value);
			$playarr = urlDealMax( iconv('gbk','utf-8',$rs->Fields(17)->Value) );
			
			$d_name = $db->real_escape_string( $d_name );
			$d_content = $db->real_escape_string( $d_content );
			$d_starring = $db->real_escape_string( $d_starring );
			$d_directed = $db->real_escape_string( $d_directed );
			$playarr['url'] = $db->real_escape_string( $playarr['url'] );
			
			$db->Add ("{pre}vod", Array("d_id","d_name","d_enname", "d_type", "d_letter", "d_state", "d_color", "d_pic", "d_starring", "d_directed", "d_area", "d_year", "d_lang", "d_level", "d_hits","d_dayhits","d_weekhits","d_monthhits", "d_content", "d_remarks", "d_addtime", "d_time", "d_playurl", "d_playfrom"), Array($rs->Fields(0)->Value,$d_name,$rs->Fields(28)->Value, $rs->Fields(2)->Value, $d_letter, $rs->Fields(3)->Value, $rs->Fields(11)->Value, $d_pic, $d_strring, $d_directed, $d_area, $rs->Fields(15)->Value, $d_lang,$rs->Fields(20)->Value, $rs->Fields(5)->Value,$rs->Fields(25)->Value, $rs->Fields(26)->Value, $rs->Fields(27)->Value , $d_content, $d_remarks , $d_addtime, $d_time, $playarr['url'], $playarr['from']) );
			
			$rs->MoveNext();
			$i++;
		}
		unset($rs);
		echo '<script>showmessage(\'视频数据导入完毕......\');</script>';
		ob_flush();flush();
		
	}
	else{
		
		
		
	}
	unset($rs,$row,$i);
	
}

function convert_ffcms()
{
	global $db,$db1,$db_tablepre_1,$db_type_1;
	
	echo '<script>showmessage(\'开始导入管理员数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."admin");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}manager", array("m_name","m_password","m_levels","m_status"),array($row["admin_name"],$row["admin_pwd"],"b,c,d,e,f,g,h,i,j","1") );
	}
	unset($rs);
	echo '<script>showmessage(\'管理员数据导入完毕......\');</script>';
	ob_flush();flush();
	
	echo '<script>showmessage(\'开始导入友情链接数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."link");
	while ($row = $db1->fetch_array($rs))
	{
		$linktype = $row["link_type"];
		if($linktype=="2"){
			$linktype="1";
		}
		else{
			$linktype="0";
		}
		$db->Add( "{pre}link", array("l_name","l_type","l_url","l_sort","l_logo"),array($row["link_name"],$linktype,$row["link_url"],$row["link_order "],$row["link_logo"]) );
	}
	unset($rs);
	echo '<script>showmessage(\'友情链接数据导入完毕......\');</script>';
	ob_flush();flush();
	
	echo '<script>showmessage(\'开始导入文章分类数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."list where list_sid=2 ");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}art_type", array("t_id","t_name","t_enname","t_sort","t_pid","t_key","t_des","t_tpl","t_tpl_list","t_tpl_art"),array($row["list_id"],$row["list_name"],$row["list_dir "],$row["list_oid"],$row["list_pid"],$row["list_keywords"],$row["list_description"],"art_type.html","art_list.html","art_detail.html") );
	}
	unset($rs);
	echo '<script>showmessage(\'文章分类数据导入完毕......\');</script>';
	ob_flush();flush();
	
	echo '<script>showmessage(\'开始导入视频分类数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."list where list_sid=1 ");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}vod_type", array("t_id","t_name","t_enname","t_sort","t_pid","t_key","t_des","t_tpl","t_tpl_list","t_tpl_vod","t_tpl_play","t_tpl_down"),array($row["list_id"],$row["list_name"],$row["list_dir"],$row["list_oid"],$row["list_pid"],$row["list_keywords"],$row["list_description"],"vod_type.html","vod_list.html","vod_detail.html","vod_play.html","vod_down.html") );
	}
	unset($rs);
	echo '<script>showmessage(\'视频数据导入完毕......\');</script>';
	ob_flush();flush();
	
	echo '<script>showmessage(\'开始导入评论数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."cm");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}comment", array("c_type","c_vid","c_rid","c_audit","c_name","c_ip","c_content","c_time"),array($row["cm_sid"],$row["cm_cid"],0,1,"游客",ip2long($row["cm_ip"]),$row["cm_content"],$row["c_addtime"]) );
	}
	unset($rs);
	echo '<script>showmessage(\'评论数据导入完毕......\');</script>';
	ob_flush();flush();
	
	echo '<script>showmessage(\'开始导入留言本数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."gb");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}gbook", array("g_vid","g_audit","g_name","g_content","g_reply","g_ip","g_time"),array(0,1,"游客",$row["gb_content"],$row["gb_intro"],ip2long($row["gb_ip"]),$row["gb_addtime"]) );
	}
	unset($rs);
	echo '<script>showmessage(\'留言本数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入文章数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."news");
	while ($row = $db1->fetch_array($rs))
	{
		$a_name = $db->real_escape_string($row['news_name']);
		$a_enname = Hanzi2Pinyin($a_name);
		$a_letter = strtoupper(substr($a_enname,0,1));
		$a_content = $db->real_escape_string($row['news_content']);
		
		$db->Add ( "{pre}art",Array("a_id","a_name","a_enname","a_letter","a_from","a_type","a_content","a_author","a_color","a_hits","a_dayhits","a_weekhits","a_monthhits","a_addtime","a_time"),Array($row["news_cid"], $a_name, $a_enname, $a_letter, $row["news_reurl"], $row["news_cid"],$a_content ,"",$row["news_color "],$row["news_hits"],$row["news_hits_day"], $row["news_hits_week"], $row["news_hits_month"], $row["news_addtime"], $row["news_addtime"]) );
	}
	unset($rs);
	echo '<script>showmessage(\'文章数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入视频数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."vod");
	while ($row = $db1->fetch_array($rs))
	{
		$d_name = $db->real_escape_string($row['vod_name']);
		$d_enname= Hanzi2Pinyin($d_name);
		$d_letter = strtoupper(substr($d_enname,0,1));
		$d_pic = strpos($row["vod_pic"],"ttp://")>0 ? $row["vod_pic"] : "upload/".$row["vod_pic"];
		//$d_playfrom = str_replace(array('bdhd','yuku'),array('baidu','youku'),$row["vod_play"]);
		//$d_playurl = str_replace(array(chr(13),chr(10)),array('','#'),$row["vod_url"]);
		$d_playfrom='';
		$d_playurl='';
		$d_downfrom='';
		$d_downurl='';
		
		$rc1=false;
		$rc2=false;
		$fromarr =  explode('$$$',$row['vod_play']);
		$urlarr = explode('$$$',$row['vod_url']);
		for($i=0;$i<count($fromarr);$i++){
			if($fromarr[$i]=='down'){
				if($rc1){
					$d_downfrom .='$$$'; 
					$d_downurl .='$$$'; 
				}
				$d_downfrom .= 'http';
				$d_downurl .= $urlarr[$i];
				$rc1=true;
			}
			else{
				if($rc2){
					$d_playfrom .='$$$'; 
					$d_playurl .='$$$'; 
				}
				$d_playfrom .= $fromarr[$i];
				$d_playurl .= $urlarr[$i];
				$rc2=true;
			}
		}
		$d_content = $db->real_escape_string( $row["vod_content"] );
		$d_starring = $db->real_escape_string( $row["vod_actor"] );
		$d_directed = $db->real_escape_string( $row["vod_director"] );
		$d_playurl = str_replace(array(chr(13),chr(10)),array('','#'),$d_playurl);
		$d_playurl = $db->real_escape_string( $d_playurl );
		$d_downurl = str_replace(array(chr(13),chr(10)),array('','#'),$d_downurl);
		$d_downurl = $db->real_escape_string( $d_downurl );
		$d_playfrom = str_replace(array('bdhd','yuku'),array('baidu','youku'),$d_playfrom);
		
		
		$status = $db->Add ("{pre}vod", Array("d_id","d_name","d_enname", "d_type", "d_letter", "d_state", "d_color", "d_pic", "d_starring", "d_directed", "d_area", "d_year", "d_lang", "d_level","d_hits","d_dayhits","d_weekhits","d_monthhits", "d_content", "d_remarks", "d_up","d_down", "d_score", "d_scorenum", "d_addtime", "d_time", "d_playurl","d_playfrom","d_downurl","d_downfrom"), Array($row["vod_id"],$d_name,$d_enname, $row["vod_cid"], $d_letter, $row["vod_continu"], $row["vod_color"] , $d_pic, $d_starring, $d_directed ,$row["vod_area"], $row["vod_year"], $row["vod_language"],$row["vod_stars"], $row["vod_hits"], $row["vod_hits_day"], $row["vod_hits_week"], $row["vod_hits_month"] , $d_content, $row["vod_title"] , $row["vod_up"], $row["vod_down"], $row["vod_gold"], $row["vod_golder"], $row["vod_addtime"], $row["vod_addtime"], $d_playurl,$d_playfrom,$d_downurl,$d_downfrom) );
		
		if(!$status){
			echo '转换数据出错：'.$row['vod_id'];exit;
		}
	}
	unset($rs);
	echo '<script>showmessage(\'视频数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	unset($rs,$row,$i);
}

function convert_maccms()
{
	global $db,$db1,$db_tablepre_1,$db_type_1;
	
	echo '<script>showmessage(\'开始导入管理员数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."manager");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}manager", array("m_name","m_password","m_levels","m_status"),array($row["m_name"],$row["m_password"],"b,c,d,e,f,g,h,i,j","1") );
	}
	unset($rs);
	echo '<script>showmessage(\'管理员数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入友情链接数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."link");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}link", array("l_name","l_type","l_url","l_sort","l_logo"),array($row["l_name"],$row["l_type"],$row["l_url"],$row["l_sort "],$row["l_logo"]) );
	}
	unset($rs);
	echo '<script>showmessage(\'友情链接数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入留言本数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."gbook");
	while ($row = $db1->fetch_array($rs))
	{
		$g_hide = $row['g_audit'] == 0 ? 1 : 0;
		$db->Add( "{pre}gbook", array("g_vid","g_hide","g_name","g_content","g_reply","g_ip","g_time","g_replytime"),array($row['g_vid'],$g_hide,$row['g_name'],$row["g_content"],$row["g_reply"],ip2long($row["g_ip"]),strtotime($row["g_time"]), strtotime($row["g_replytime"])) );
	}
	unset($rs);
	echo '<script>showmessage(\'留言本数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入评论数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."comment");
	while ($row = $db1->fetch_array($rs))
	{
		$c_hide = $row['c_audit'] == 0 ? 1 : 0;
		
		$db->Add( "{pre}comment", array("c_type","c_vid","c_rid","c_hide","c_name","c_ip","c_content","c_time"),array($row["c_type"],$row["c_vid"],$row['c_rid'],$c_hide,$row['c_name'],ip2long($row["c_ip"]),$row["c_content"],strtotime($row["c_time"]) ) );
	}
	unset($rs);
	echo '<script>showmessage(\'评论数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入会员组数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."user_group");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}user_group", array( "ug_id","ug_name","ug_type","ug_popedom","ug_upgrade","ug_popvalue"),array($row["ug_id"],$row["ug_name"],$row['ug_type'],$row['ug_popedom'],$row['ug_upgrade'],$row['ug_popvalue']) );
	}
	unset($rs);
	echo '<script>showmessage(\'会员组数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入会员数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."user");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}user", array( "u_id","u_qid","u_name","u_password","u_qq","u_email","u_phone","u_status","u_flag","u_question","u_answer","u_group",  "u_points","u_regtime","u_logintime","u_loginnum","u_extend","u_loginip","u_random","u_fav","u_plays","u_downs","u_start","u_end"),array($row["u_id"],$row["u_qid"],$row['u_name'],$row['u_password'],$row['u_qq'],$row['u_email'],$row['u_phone'],$row['u_status'],$row['u_flag'],$row['u_question'],$row['u_answer'],$row['u_group'],$row['u_points'],strtotime($row['u_regtime']),strtotime($row['u_logintime']),$row['u_loginnum'],$row['u_tj'],ip2long($row["u_loginip"]),$row["u_random"],$row["u_fav"],$row['u_plays'],$row['u_downs'],$row['u_start'],$row['u_end'] ) );
	}
	unset($rs);
	echo '<script>showmessage(\'会员数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	
	echo '<script>showmessage(\'开始导入文章专题数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."art_topic");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}art_topic", array("t_id","t_name","t_enname","t_sort","t_tpl","t_pic","t_content"),array($row["t_id"],$row["t_name"],$row["t_enname "],$row["t_sort"],$row["t_template"],$row["t_pic"],$row["t_des"]) );
		
		$rs1 = $db1->query("select * from ".$db_tablepre_1."art where a_topic=" .$row['t_id']);
		while ($row1 = $db1->fetch_array($rs1))
		{
			$db->Add( "{pre}art_relation", array('r_type','r_a','r_b'),array(2,$row['t_id'],$row1['a_id']) );
		}
		unset($rs1);
		echo '<script>showmessage(\'文章专题【'.$row['t_name'].'】包含的文章数据导入完毕......\');</script>';
		ob_flush();flush();
	}
	unset($rs);
	echo '<script>showmessage(\'视频专题数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入视频专题数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."vod_topic");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}vod_topic", array("t_id","t_name","t_enname","t_sort","t_tpl","t_pic","t_content"),array($row["t_id"],$row["t_name"],$row["t_enname "],$row["t_sort"],$row["t_template"],$row["t_pic"],$row["t_des"]) );
		
		$rs1 = $db1->query("select * from ".$db_tablepre_1."vod where d_topic=" .$row['t_id']);
		while ($row1 = $db1->fetch_array($rs1))
		{
			$db->Add( "{pre}vod_relation", array('r_type','r_a','r_b'),array(2,$row['t_id'],$row1['d_id']) );
		}
		unset($rs1);
		echo '<script>showmessage(\'视频专题【'.$row['t_name'].'】包含的视频数据导入完毕......\');</script>';
		ob_flush();flush();
	}
	unset($rs);
	echo '<script>showmessage(\'视频专题数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入文章分类数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."art_type ");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}art_type", array("t_id","t_name","t_enname","t_sort","t_pid","t_key","t_des","t_tpl","t_tpl_list","t_tpl_art"),array($row["t_id"],$row["t_name"],$row["t_enname "],$row["t_sort"],$row["t_pid"],$row["t_key"],$row["t_des"],"art_type.html","art_list.html","art_detail.html") );
	}
	unset($rs);
	echo '<script>showmessage(\'文章分类数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入视频分类数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."vod_type ");
	while ($row = $db1->fetch_array($rs))
	{
		$db->Add( "{pre}vod_type", array("t_id","t_name","t_enname","t_sort","t_pid","t_key","t_des","t_tpl","t_tpl_list","t_tpl_vod","t_tpl_play","t_tpl_down"),array($row["t_id"],$row["t_name"],$row["t_enname "],$row["t_sort"],$row["t_pid"],$row["t_key"],$row["t_des"],"vod_type.html","vod_list.html","vod_detail.html","vod_play.html","vod_down.html") );
	}
	unset($rs);
	echo '<script>showmessage(\'视频分类数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	
	echo '<script>showmessage(\'开始导入文章数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."art");
	while ($row = $db1->fetch_array($rs))
	{
		$a_content = $db->real_escape_string( $row["a_content"] );
		
		$db->Add ( "{pre}art",Array("a_id","a_name","a_subname","a_enname","a_letter","a_from","a_type","a_content","a_author","a_color","a_hits","a_dayhits","a_weekhits","a_monthhits","a_addtime","a_time"),Array($row["a_id"],$row["a_title"],$row['a_subtitle'],$row['a_entitle'],$row['a_letter'],$row["a_from"],$row["a_type"],$a_content ,$row['a_author'], $row["a_color"],$row["a_hits"], $row["a_dayhits"], $row["a_weekhits"], $row["a_monthhits"], strtotime($row["a_addtime"]), strtotime($row["a_time"])) );
	}
	unset($rs);
	echo '<script>showmessage(\'文章数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	echo '<script>showmessage(\'开始导入视频数据，请稍候......\');</script>';
	$rs = $db1->query("select * from ".$db_tablepre_1."vod");
	while ($row = $db1->fetch_array($rs))
	{
		$d_content = $db->real_escape_string( $row["d_content"] );
		$d_starring = $db->real_escape_string( $row["d_starring"] );
		$d_directed = $db->real_escape_string( $row["d_directed"] );
		$d_playurl = $db->real_escape_string( $row["d_playurl"] );
		$d_downurl = $db->real_escape_string( $row["d_downurl"] );
		
		$db->Add ("{pre}vod", Array("d_id","d_name","d_enname", "d_type", "d_letter", "d_state", "d_color", "d_pic", "d_starring", "d_directed", "d_area", "d_year", "d_lang", "d_level","d_hits","d_dayhits","d_weekhits","d_monthhits", "d_content", "d_remarks", "d_up","d_down", "d_score", "d_scorenum", "d_addtime", "d_time", "d_playurl","d_playfrom","d_playserver","d_downurl","d_downfrom","d_downserver"), Array($row["d_id"],$row["d_name"],$row['d_enname'], $row["d_type"], $row['d_letter'], $row["d_state"], $row["d_color"] , $row['d_pic'], $d_starring, $d_directed , $row["d_area"], $row["d_year"], $row["d_language"],$row["d_level"], $row["d_hits"], $row["d_dayhits"], $row["d_weekhits"], $row["d_monthhits"] , $d_content, $row["d_remarks"] , $row["d_up"], $row["d_down"], $row["d_score"], $row["d_scorenum"], strtotime($row["d_addtime"]), strtotime($row["d_time"]), $d_playurl ,$row['d_playfrom'],$row['d_playserver'], $d_downurl ,$row['d_downfrom'],$row['d_downserver']) );
	}
	unset($rs);
	echo '<script>showmessage(\'视频数据导入完毕......\');</script>';
	ob_flush();flush();
	
	
	unset($rs,$row,$row1,$i);
}

function stepC()
{
	global $MAC,$db,$db1,$db_tablepre_1,$db_type_1;
	
	$xt = be("all","xt");
	$db_type_1 = be("post","db_type_1");
	$db_path_1 = be("post","db_path_1");
	$db_server_1 = be("post","db_server_1");
	$db_name_1 = be("post","db_name_1");
	$db_user_1 = be("post","db_user_1");
	$db_pass_1 = be("post","db_pass_1");
	$db_tablepre_1 = be("post","db_tablepre_1");
	$pg = intval(be("all","pg"));
	
	show_step(3,"转换数据","正在执行数据转换任务");
	
echo <<<EOT
	<div class="main"> 
	<div class="btnbox"><div id="notice"></div></div>
	<div class="btnbox margintop marginbot"><form method="get" autocomplete="off" action="convertdata.php">
	<table class="tb2"><tr><th class="tbopt" align="left">&nbsp;</th><td>
<input type="hidden" name="action" value="d" /><div class="btnbox marginbot"><input type="button" onclick="history.back();" value="上一步"><input type="submit" value="下一步"></td><td></td></tr></table></form></div>
EOT;
	
	if($db_type_1=='access'){
		$db1 = new com("ADODB.Connection");
		$connstr = "DRIVER={Microsoft Access Driver (*.mdb)}; DBQ=". realpath($db_path_1);
		$connstr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=".realpath($db_path_1);
		$db1->Open($connstr);
	}
	elseif($db_type_1=='mysql'){
		$db1 = new AppMysql($db_server_1,$db_user_1,$db_pass_1,$db_name_1,'utf8',true);
	}
	elseif($db_type_1=='mysqli'){
		$db1 = new AppMysqli($db_server_1,$db_user_1,$db_pass_1,$db_name_1,'utf8',true);
	}
	
	if($MAC['db']['type']=='mysql'){
		$db = new AppMysql($MAC['db']['server'],$MAC['db']['user'],$MAC['db']['pass'],$MAC['db']['name'],'utf8',true);
	}
	else{
		$db = new AppMysqli($MAC['db']['server'],$MAC['db']['user'],$MAC['db']['pass'],$MAC['db']['name'],'utf8',true);
	}
	
	
	
	
	if($pg==0){
		echo '<script>showmessage(\'正在清空当前数据库,请稍候...... \');</script>';
		$db->query( "truncate table {pre}art");
		$db->query( "truncate table {pre}art_topic");
		$db->query( "truncate table {pre}art_type");
		$db->query( "truncate table {pre}art_relation");
		$db->query( "truncate table {pre}comment");
		$db->query( "truncate table {pre}gbook");
		$db->query( "truncate table {pre}link");
		$db->query( "truncate table {pre}manager");
		$db->query( "truncate table {pre}user");
		$db->query( "truncate table {pre}user_card");
		$db->query( "truncate table {pre}user_group");
		$db->query( "truncate table {pre}user_visit");
		$db->query( "truncate table {pre}vod");
		$db->query( "truncate table {pre}vod_topic");
		$db->query( "truncate table {pre}vod_type");
		$db->query( "truncate table {pre}vod_relation");
	}
	
	
	if($xt=='maccms'){
		convert_maccms();
	}
	elseif($xt=='maxcms'){
		convert_maxcms();
	}
	elseif($xt=='ffcms'){
		convert_ffcms();
	}
	else{
		alert("选择转换系统为空，无法进行下一步");
	}
	
	echo '<script>showmessage(\'数据转换完毕...... \');</script>';
	
	updateCacheFile();
	echo '<script>showmessage(\'数据缓存更新...... \');</script>';
	
	unset($db,$db1);
}
 
function stepD()
{
	show_step(4,"数据转换完毕","稍后进入后台管理页面");
?>
<div class="main"><div class="desc">5秒后自动跳转到后台管理登录页面...</div>
<script> setTimeout("jump();",5000); function jump(){location.href='admin/index.php';} </script>
<?php
}
?>