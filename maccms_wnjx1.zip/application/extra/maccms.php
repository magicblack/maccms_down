<?php
return array (
  'admin' => 
  array (
    'name' => 'admin1',
    'pass' => 'admin1',
  ),
  'site' => 
  array (
    'install_dir' => '/',
    'site_status' => '1',
    'site_logo' => '',
    'template_dir' => 'default',
    'html_dir' => 'html',
    'site_close_tip' => '站点暂时关闭，请稍后访问',
  ),
  'app' => 
  array (
    'useragent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36 Edg/87.0.664.57',
    'ignore_suffix' => 'zip|rar|doc|pdf|7z',
    'img_status' => '0',
    'img_file' => 'img.php',
    'zy_status' => '0',
    'ip_status' => '0',
    'cache_type' => 'file',
    'cache_host' => '127.0.0.1',
    'cache_port' => '11211',
    'cache_username' => '',
    'cache_password' => '',
    'cache_flag' => 'a6bcf9aa58',
    'cache_page' => '0',
    'cache_time_page' => '3600',
    'compress' => '0',
    'browser_junmp' => '0',
    'page_404' => '404',
    'lang' => 'zh-cn',
    'useragent_arr' => 
    array (
      0 => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36 Edg/87.0.664.57',
    ),
  ),
  'rewrite' => 
  array (
    'route' => '<p?>   => index/index',
  ),
  'view' => NULL,
  'path' => NULL,
  'spider' => 
  array (
    'status' => '0',
    'rule' => 'yahoo|bing',
  ),
  'external' => 
  array (
    'status' => '0',
    'encode' => '0',
    'mode' => '1',
    'file' => 'link.php',
    'ignore_domain' => '',
  ),
);