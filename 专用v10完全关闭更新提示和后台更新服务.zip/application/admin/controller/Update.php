<?php
namespace app\admin\controller;
use think\Db;

class Update extends Base
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        echo '已经关闭在线升级服务';
    }
}